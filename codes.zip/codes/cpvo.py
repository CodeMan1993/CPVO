#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct  1 09:57:27 2018

@author: zk
"""

import matplotlib.image as mpimg # mpimg 用于读取图片
import numpy as np
#import config
import pickle
from sys import path


code_root = 'data_and_mytools'
if code_root not in path:
    path.insert(0, code_root)  # 添加路径
from mytools import run_length_coding, PSNR, int2bin, SSIM

AUX_NUM = 61


class CPVO:
    """
    PVO-based scheme with changeable step size
    """
    
    def __init__(self, imageArr, block_size = None, step_size = None, T = None):
        imageArr = imageArr.astype(int) #转为整型才能计算
        self.imageArr = imageArr
        self.imageList = imageArr.reshape(-1)
        #self.imageArr2 = copy.deepcopy(imageArr)  # 深坑啊
        self.rows, self.cols = imageArr.shape
        self.block_size = block_size
        self.LOG_N = int(np.log2(self.rows*self.cols))
        self.CODING_LENGTH = self.LOG_N + 1
        self.T = T
        self.step_size = step_size
        
    def embedding(self, payloads):
        
        print("Embedding......")
 
        #compressed_location_map = run_length_coding(location_map, coding_length = self.CODING_LENGTH) 
        T = self.T
        step_size = self.step_size
        
        # 取出最后一行的 LSBs
        LSBs = [self.imageList[i]%2 for i in range(-AUX_NUM, 0)] 
        P = payloads + LSBs

        location_map = np.zeros_like(self.imageArr) 
        
        flag = 0 # 用来标识嵌入数据时是在哪个地方停止，默认为0，最小值处停止 
        mark = 0
        end_mark = self.rows*self.cols   # 标记后留出几行给 sideInfo 
        location_map_nums = 0

        try:
            tmp_EC = 0
            for i in range(0, self.rows-self.block_size[0], step_size[0]):
                for j in range(0, self.cols-self.block_size[1], step_size[1]):
                    
                    if (i+2+self.block_size[0])*self.cols+j >= end_mark or mark >= len(P):
                        break
                    
                    array = self.imageArr[i:i+self.block_size[0], j:j+self.block_size[1]]
                    sort_idx = argsort_for_2d(array, self.block_size) 
    
                    if self.Complexity((i, j), self.block_size) < T:
                        u, v = min([sort_idx[-1], sort_idx[-2]]), max([sort_idx[-1], sort_idx[-2]])
                        d_max = array[u] - array[v]
                        x, y = i+sort_idx[-1][0], j+sort_idx[-1][1]
                        flag_for_mark = False
                        if d_max > 1 or d_max < 0:
                            if self.imageArr[x,y]+1 > 255:  # 溢出问题
                                location_map[i,j] = 1
                                L = run_length_coding(location_map.reshape(-1), coding_length = self.CODING_LENGTH)   
                                end_mark = self.rows*self.cols - len(L) - AUX_NUM
                                P += list(reversed([self.imageList[i]%2 for i in range(-AUX_NUM-len(L), -AUX_NUM-location_map_nums)]))
                                location_map_nums = len(L)
                                continue
                            else:
                                self.imageArr[x,y] += 1
                        elif d_max == 1 or d_max == 0:
                            if self.imageArr[x,y] + P[mark] > 255:
                                location_map[i,j] = 1
                                L = run_length_coding(location_map.reshape(-1), coding_length = self.CODING_LENGTH)   
                                end_mark = self.rows*self.cols - len(L) - AUX_NUM
                                P += list(reversed([self.imageList[i]%2 for i in range(-AUX_NUM-len(L), -AUX_NUM-location_map_nums)]))
                                location_map_nums = len(L)
                                continue
                            else:
                                self.imageArr[x,y] += P[mark]
                                mark += 1
                                flag_for_mark = True
                                if mark == len(P):
                                    k_end = i*self.rows + j
                                    flag = 1
                                    break
                              
                        # 最小值
                        s, t = min([sort_idx[0], sort_idx[1]]), max([sort_idx[0], sort_idx[1]])
                        d_min = array[s] - array[t]
                        m, n = i+sort_idx[0][0], j+sort_idx[0][1]
                        
                        if d_min > 1 or d_min < 0:
                            if self.imageArr[m,n]-1 < 0:
                                location_map[i,j] = 1 # 在最小值方向，要恢复在最大值方向可能做的改变
                                self.imageArr[x,y] = array[sort_idx[-1][0], sort_idx[-1][1]]
                                if flag_for_mark:  # 如果嵌入数据，要滚回
                                    mark -= 1
                                L = run_length_coding(location_map.reshape(-1), coding_length = self.CODING_LENGTH)   
                                end_mark = self.rows*self.cols - len(L) - AUX_NUM
                                P += list(reversed([self.imageList[i]%2 for i in range(-AUX_NUM-len(L), -AUX_NUM-location_map_nums)]))
                                location_map_nums = len(L)
                                continue
                            else:
                                self.imageArr[m,n] -= 1
                                
                        if d_min == 1 or d_min == 0:
                            if self.imageArr[m,n]-P[mark]< 0:
                                location_map[i,j] = 1 # 在最小值方向，要恢复在最大值方向可能做的改变
                                self.imageArr[x,y] = array[sort_idx[-1][0], sort_idx[-1][1]]
                                if flag_for_mark:  # 如果嵌入数据，要滚回
                                    mark -= 1
                                L = run_length_coding(location_map.reshape(-1), coding_length = self.CODING_LENGTH)   
                                end_mark = self.rows*self.cols - len(L) - AUX_NUM    
                                P += list(reversed([self.imageList[i]%2 for i in range(-AUX_NUM-len(L), -AUX_NUM-location_map_nums)]))
                                location_map_nums = len(L)
                                continue
                            else:
                                self.imageArr[m,n] -= P[mark]
                                mark += 1
                                if mark == len(P):
                                    k_end = k_end = i*self.rows + j
                                    break
                        tmp_EC = mark
            compressed_location_map = run_length_coding(location_map.reshape(-1), coding_length = self.CODING_LENGTH)          
            sideInfo = compressed_location_map + int2bin(self.block_size[0], 4) + int2bin(self.block_size[1], 4) + \
                       int2bin(step_size[0], 3) + int2bin(step_size[1], 3) + int2bin(T, 10) + int2bin(len(compressed_location_map), self.LOG_N) +\
                       int2bin(k_end, self.LOG_N) + [flag] 
            len_side_info = len(sideInfo)
            
            # embedding sideInfo
            tmp_list = self.imageArr.reshape(-1)
            for i in range(len_side_info):
                tmp_list[-len_side_info+i] = (tmp_list[-len_side_info+i] // 2)*2 + sideInfo[i]
            
            self.imageArr = np.reshape(tmp_list, self.imageArr.shape)
            
            print("length of location map：", len(compressed_location_map))
            print("k_end = ", k_end)
            print("embed ending)")
            print("------------------------------------")
        
            return self.imageArr.astype(np.uint8)
        except:
            print("maximum EC：", tmp_EC)
            
    def extracting(self):
        
        print("Extracting......")
       
        LSBs = [self.imageList[i]%2 for i in range(-AUX_NUM, 0)]
        block_size, step_size, T, len_location_map, k_end, flag = (int2bin(LSBs[:4]), int2bin(LSBs[4:8])),\
                    (int2bin(LSBs[8:11]), int2bin(LSBs[11:14])), int2bin(LSBs[14:24]), \
                    int2bin(LSBs[24:24+self.LOG_N]), int2bin(LSBs[24+self.LOG_N:24+2*self.LOG_N]), LSBs[-1]  # 应该是 -1 哇             
        
        print(step_size)
        print("length of location map：", len_location_map)
        print("k_end = ", k_end)
        print("T = ", T)
        # restore location_map
        compressed_location_map = [self.imageList[i]%2 for i in range(-AUX_NUM-len_location_map,-AUX_NUM)]
        
        if compressed_location_map == []:
            location_map = np.zeros_like(self.imageArr)
        else:
            location_map = np.reshape(run_length_coding(compressed_location_map, flag = "decompress", coding_length = self.CODING_LENGTH), self.imageArr.shape) 

        end_row, end_col = k_end//self.cols, k_end % self.cols

        P = []
        end = max([i for i in range(500, 512) if i % step_size[1] == 0 and i + block_size[1] < self.cols])
        for i in range(end_row, -1, -step_size[0]):
            for j in range(end, -1, -step_size[1]):
                if i == end_row and j > end_col:
                    continue
                array = self.imageArr[i:i+block_size[0], j:j+block_size[1]]
                sort_idx = argsort_for_2d(array, block_size) 
                if self.Complexity((i, j), block_size) < T and location_map[i,j] == 0:
                    tmp = []
                    # the maximum
                    u, v = min([sort_idx[-1], sort_idx[-2]]), max([sort_idx[-1], sort_idx[-2]])
                    d_max = array[u] - array[v]
                    
                    x, y = i+sort_idx[-1][0], j+sort_idx[-1][1]
                    
                    if d_max in [1, 2]:
                        b = d_max - 1
                        tmp.append(b)
                        self.imageArr[x,y] -= b
                    
                    elif d_max in [0, -1]:
                        b = -d_max
                        tmp.append(b)
                        self.imageArr[x,y] -= b
                        
                    else:
                        self.imageArr[x,y] -= 1
                    
                    # 抽取的时候在最大值时停止？还是在最小值处停止？
                    if i*self.rows + j == k_end and flag == 1:
                        P = tmp + P
                        continue
                    # the minimum
                    s, t = min([sort_idx[0], sort_idx[1]]), max([sort_idx[0], sort_idx[1]])
                    d_min = array[s] - array[t]
                    
                    m, n = i+sort_idx[0][0], j+sort_idx[0][1]
                    if d_min in [1, 2]:
                        b = d_min - 1
                        tmp.append(b)
                        self.imageArr[m,n] += b
                   
                    elif d_min in [0, -1]:
                        b = -d_min
                        tmp.append(b)
                        self.imageArr[m,n] += b
                        
                    else:
                        self.imageArr[m,n] += 1
                    P = tmp + P
        
        payloads = P[:-AUX_NUM-len_location_map]
        if len_location_map == 0:
            sideInfo = P[-AUX_NUM:]
        else:
            sideInfo = list(reversed(P[-len_location_map:])) + P[-AUX_NUM-len_location_map:-len_location_map] 
        len_side_info = len(sideInfo)

        tmp_list = self.imageArr.reshape(-1)
        for i in range(len_side_info):
            tmp_list[-len_side_info+i] = (tmp_list[-len_side_info+i] // 2)*2 + sideInfo[i]
        
        self.imageArr = np.reshape(tmp_list, self.imageArr.shape)
        
        print("extract ending :)")
        print("------------------------------------")
        return self.imageArr.astype(np.uint8), payloads
        
    def Complexity(self, Locate, block_size):
        # Locate: 为像素块的左上角像素坐标
        # the last line and column can't be used to
        
        P = [self.imageArr[Locate[0]+i, Locate[1]+block_size[1]] for i in range(block_size[0])]
        
        if Locate[1]+block_size[1]+1 >= self.cols:
            Q = P
            R = [self.imageArr[Locate[0]+block_size[0], Locate[1]+i] for i in range(block_size[1]+1)]
            R.append(R[-1])
        else:
            Q = [self.imageArr[Locate[0]+i, Locate[1]+block_size[1]+1] for i in range(block_size[0])]
            R = [self.imageArr[Locate[0]+block_size[0], Locate[1]+i] for i in range(block_size[1]+2)]
        
        if Locate[0]+block_size[0]+1 >= self.rows:
            S = R
        elif Locate[1]+block_size[1]+1 >= self.cols:    
            S = [self.imageArr[Locate[0]+block_size[0]+1, Locate[1]+i] for i in range(block_size[1]+1)]
            S.append(S[-1])
        else:
            S = [self.imageArr[Locate[0]+block_size[0]+1, Locate[1]+i] for i in range(block_size[1]+2)]
        hor = sum([abs(P[i]-Q[i]) for i in range(block_size[0])]  +\
                  [abs(R[i]-R[i+1]) for i in range(block_size[1]+1)] +\
                  [abs(S[i]-S[i+1]) for i in range(block_size[1]+1)])    
        
        ver = sum([abs(P[i]-P[i+1]) for i in range(block_size[0]-1)]  +\
                  [abs(Q[i]-Q[i+1]) for i in range(block_size[0]-1)] +\
                  [abs(R[i]-S[i]) for i in range(block_size[1]+2)]) + \
                  abs(P[-1]-R[-2]) + abs(Q[-1]-R[-1])
        
        return hor+ver
      
def argsort_for_2d(array, block_size):
    
    pixel_sort_idx = np.argsort(array.ravel())
    
    return [(i//block_size[1], i%block_size[1]) for i in pixel_sort_idx]



def original_main():
    # demo for lena
    image_root = 'test_images/'
    test_name = ["lena_gray_512.tif", "baboon.tiff", "jetplane.tiff","boat512.tiff", "man.tiff", "lake.tiff",
              "Aerial.tiff", "Couple.tiff", 'Tank2.tiff', 'Truck.tiff', 'Tank.tiff', 'Car_and_APCs.tiff']
    filename = image_root + test_name[9]  #(512, 512)
    image = mpimg.imread(filename)
    
    block_size = (2, 4)
    step_size = (2, 4)
    
    # thereshold: 1~1023
    T = 63
    
    cpvo = CPVO(image, block_size, step_size, T)
    #pso.divided_and_sorted_for_hist()
    with open("data_and_mytools/data.pickle", "rb") as f:
        data = pickle.load(f)
    
    N = 5000
    payloads = data[:N] # 最大取 38000
    
    new_image = cpvo.embedding(payloads)
    print("bpp ", N / (512*512))
    print(PSNR(image, new_image))
    
    print(SSIM(image, new_image))
    
    #divided_and_sorted_for_hist(new_image, block_size)
    #plt.imshow(new_image, cmap = 'Greys_r')
    #plt.axis('off') 
    #plt.title("the image after encoding")
    
    cpvo_dec = CPVO(new_image)
    sourceImage, watermark = cpvo_dec.extracting()

    print("------------------------------------")
     
    print("payloads numbe: ", len(payloads))
    print("watermark numbe: ", len(watermark))
    
    if payloads == watermark: # compare hidden bits
        print("decoding correct")
    else:
        print("decoding error")
    if (image == sourceImage).all():
        print("restore the host iamge correctly")
    else:
        print("restore the host iamge error") 

if __name__ == "__main__":

    original_main()
    
