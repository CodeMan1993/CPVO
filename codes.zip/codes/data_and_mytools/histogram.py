#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 09:05:28 2018

@author: zk
"""

"""
本文件用来生成图片的像素分布图
"""
import matplotlib.image as mpimg # mpimg 用于读取图片
import matplotlib.pyplot as plt # plt 用于显示图片
import numpy as np


def histogram(imageArr):
    imageArr = imageArr.astype(int)
    pixelDic = {}
    for key in list(imageArr.reshape(-1)):
        if key in pixelDic.keys():
            pixelDic[key] += 1
        else:
            pixelDic[key] = 1

    fig, ax = plt.subplots(1,1,figsize=(5,3))

    ax.bar(range(2**8), [pixelDic[i] if i in pixelDic.keys() else 0 for i in range(2**8)])
    
    plt.title(u"distribution of pixel values")
    
    ax.spines['right'].set_color('none')
    ax.spines['top'].set_color('none')
    #plt.yticks(())  # ignore yticks
    plt.xlabel("pixel value")
    plt.ylabel("Occurence")

    plt.show() 

if __name__ == "__main__":

    image_root = '../test_images/'#os.path.abspath('..')+
    file_name = ["lena_gray_512.tif", "baboon.tiff", "jetplane.tiff","boat512.tiff", "man.tiff", "lake.tiff",
              "Aerial.tiff", "Couple.tiff", 'Tank2.tiff', 'Truck.tiff', 'Tank.tiff', 'Car_and_APCs.tiff']
    
    filename = image_root + file_name[0]  #(512, 512)
    image = mpimg.imread(filename)
    
    histogram(image)